java -Xmx1024M -cp nxt.jar:lib/*:conf nxt.Nxt
